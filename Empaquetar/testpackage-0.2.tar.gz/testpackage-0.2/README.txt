Empaquetamiento Básico - dh_make

Para instalar el script use la siguiente línea
	
	make install DESTDIR=RUTA/DONDE/QUIERE/INSTALAR/EL/SCRIPT

Recuerde que la ruta en la cual usted va a instalar el script debe tener
la siguiente jeraquía de carpetas

	RUTA/DONDE/QUIERE/INSTALAR/EL/SCRIPT/
		└── usr
		    └── bin

El manual del script se encuentra en la carpeta 'docs'

